const synthetics = require('Synthetics');

exports.handler = async () => {
  await synthetics.executeHttpStep(
    'FTH Pay Health Check',
    {
      hostname: 'fth-api.unykorn.org',
      method:   'GET',
      path:     '/health',
      port:     443,
      protocol: 'https:'
    }
  );
};
